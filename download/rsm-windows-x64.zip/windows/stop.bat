@echo off
title RSM - Stop the server
echo To stop the RSM server:
echo.
echo   1. Go to the RSM console window - the one running windows\start.bat
echo   2. Press Ctrl+C, or simply close that window.
echo.
echo This window is only a reminder - closing it changes nothing.
echo.
pause
