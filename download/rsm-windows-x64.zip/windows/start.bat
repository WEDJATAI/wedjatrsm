@echo off
title RSM Restaurant Platform
cd /d "%~dp0.."
if not exist node_modules goto notinstalled
where bun >nul 2>nul
if %errorlevel% equ 0 goto bun
where node >nul 2>nul
if %errorlevel% equ 0 goto node
echo [ERROR] Neither Bun nor Node.js was found. Run windows\install.bat first.
pause
exit /b 1

:bun
call bunx prisma generate >nul 2>nul
echo Starting RSM... once ready, open http://localhost:3000
echo Keep this window open while working. Press Ctrl+C to stop the server.
echo.
call bun x next dev -p 3000
goto stopped

:node
call npx prisma generate >nul 2>nul
echo Starting RSM... once ready, open http://localhost:3000
echo Keep this window open while working. Press Ctrl+C to stop the server.
echo.
call npx next dev -p 3000
goto stopped

:notinstalled
echo [ERROR] Dependencies are not installed yet.
echo Please double-click windows\install.bat first, then run this file again.
echo.
pause
exit /b 1

:stopped
echo.
echo RSM stopped. If an error appeared above, read it, fix it, then start again.
pause
