@echo off
title RSM Restaurant Platform - Installer
echo ==========================================================
echo   RSM Restaurant Platform - Windows Installer
echo ==========================================================
echo.
cd /d "%~dp0.."
where bun >nul 2>nul
if %errorlevel% equ 0 goto bun
where node >nul 2>nul
if %errorlevel% equ 0 goto node
echo [ERROR] Neither Bun nor Node.js was found on this PC.
echo.
echo Please install ONE of the following, then run this file again:
echo    Bun:      https://bun.com
echo    Node.js:  https://nodejs.org   version 20 or newer
echo.
pause
exit /b 1

:bun
echo [OK] Bun detected. Installing dependencies - usually 1-3 minutes...
call bun install
if errorlevel 1 goto installfailed
echo [OK] Generating the database client...
call bunx prisma generate
if errorlevel 1 goto installfailed
goto done

:node
echo [OK] Node.js detected. Installing dependencies - usually 3-10 minutes...
call npm install --no-audit --no-fund
if errorlevel 1 goto installfailed
echo [OK] Generating the database client...
call npx prisma generate
if errorlevel 1 goto installfailed
goto done

:installfailed
echo.
echo [ERROR] Installation failed. Read the messages above.
echo If an antivirus or firewall blocked something, allow it and run this file again.
pause
exit /b 1

:done
echo.
echo ==========================================================
echo   Install complete!
echo   Next: double-click windows\start.bat to run RSM.
echo ==========================================================
pause
