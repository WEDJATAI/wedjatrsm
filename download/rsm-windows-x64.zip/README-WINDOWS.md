# RSM Restaurant Platform — Windows Package

## English

**What this is:** the complete RSM restaurant platform (POS, kitchen
display, inventory, cash drawer, reports, reservations, loyalty, AI vision
dashboard) packaged to run **100% locally on your PC**. All data is stored
in the single file `db\custom.db` (SQLite). **No internet connection is
required to operate the restaurant** — everything runs on your machine.

### Requirements
- Windows 10/11 64-bit
- **Bun** (https://bun.com) **or** Node.js 20+ (https://nodejs.org)

### Setup (once)
1. Unzip this package to a folder, e.g. `C:\RSM`.
2. Double-click `windows\install.bat` — it installs dependencies and the
   database client (needs internet, a few minutes, only once).
3. Double-click `windows\start.bat`.
4. Open **http://localhost:3000** in Chrome/Edge.
5. Sign in:
   - Admin: `admin@rms.com` / `admin123` (PIN 1234)
   - Waiter: `waiter@rms.com` / `waiter123` (PIN 1111)
   - Kitchen: `kitchen@rms.com` / `kitchen123` (PIN 2222)

### Where your data lives & how to back it up
Everything is in `db\custom.db`. From the app: **Settings → Backup** to
create and download snapshots (stored in the `backups\` folder). Copy the
whole folder to move the restaurant to another PC.

### Syncing to the cloud (when online)
When the PC is connected to the internet it can export its updates to your
**hosted master instance** automatically:
1. On the PC instance open **Settings → Sync Center**.
2. Set the **Cloud target URL** to your hosted master's address
   (e.g. `https://master.example.com`) and paste the **sync key** from the
   master's Sync Center (Settings → Sync Center → sync key).
3. Enable **auto-export**.
4. Whenever the PC is online, its updates (orders, payments, customers,
   attendance, cash entries, reservations, activity log) export to the
   master. You can also push manually any time.

### Firewall note
The first time you start the server, Windows may ask to allow Node/Bun —
tick **Private networks** and allow it. The app only listens on your own PC
(localhost); outbound sync needs the internet.

### Troubleshooting
- **Port 3000 busy** (`EADDRINUSE`): another app uses the port — close it
  (or stop the other RSM console) and run `windows\start.bat` again.
- **Antivirus slows the install or flags the server**: allow/whitelist the
  folder — the app is a local Node server, no external code runs on your PC.
- **Blank page on first start**: the server compiles for a minute on the
  very first run — refresh after ~60 seconds.

---

## العربية

**ما هذه الحزمة:** منصة إدارة المطاعم RSM كاملة (نقاط البيع، شاشة
المطبخ، المخزون، درج النقدية، التقارير، الحجوزات، الولاء، لوحة
الرؤية الذكية) معدّة للعمل **بالكامل على جهازك محليًا**. جميع
البيانات تُحفظ في ملف واحد `db\custom.db`. **لا تحتاج اتصالًا
بالإنترنت لتشغيل المطعم** — كل شيء يعمل على جهازك.

### المتطلبات
- ويندوز 10/11 (64-بت)
- **Bun** (https://bun.com) **أو** Node.js 20 أو أحدث (https://nodejs.org)

### خطوات التشغيل (مرة واحدة)
1. فك ضغط الحزمة في مجلد مثل `C:\RSM`.
2. شغّل `windows\install.bat` بالنقر المزدوج — يثبّت المتطلبات وعميل
   قاعدة البيانات (يحتاج إنترنت، بضع دقائق، مرة واحدة فقط).
3. شغّل `windows\start.bat` بالنقر المزدوج.
4. افتح **http://localhost:3000** في المتصفح.
5. سجّل الدخول:
   - مدير: `admin@rms.com` / `admin123` (رمز 1234)
   - نادل: `waiter@rms.com` / `waiter123` (رمز 1111)
   - مطبخ: `kitchen@rms.com` / `kitchen123` (رمز 2222)

### أين تُحفظ البيانات وكيف تأخذ نسخة احتياطية
كل شيء في `db\custom.db`. من التطبيق: **الإعدادات ← النسخ الاحتياطي**
لإنشاء نسخ وتحميلها (تُحفظ في مجلد `backups\`). انسخ المجلد كاملًا
لنقل المطعم إلى جهاز آخر.

### المزامنة مع السحابة (عند توفر الإنترنت)
عند اتصال الجهاز بالإنترنت يمكن تصدير التحديثات تلقائيًا إلى
**النسخة المستضافة** لديك:
1. افتح **الإعدادات ← مركز المزامنة** على جهازك.
2. ضع **عنوان النسخة السحابية** (مثل `https://master.example.com`)
   وألصق **مفتاح المزامنة** من مركز المزامنة في النسخة المستضافة.
3. فعّل **التصدير التلقائي**.
4. عند توفر الإنترنت تُصدَّر التحديثات (الطلبات، المدفوعات، العملاء،
   الحضور، حركات النقدية، الحجوزات، سجل النشاط) إلى النسخة الرئيسية.
   ويمكن أيضًا التصدير يدويًا في أي وقت.

### ملاحظة جدار الحماية
عند أول تشغيل قد يطلب ويندوز السماح لـ Node/Bun — اختر **الشبكات
الخاصة** واسمح بذلك. التطبيق يعمل على جهازك فقط (localhost)،
والمزامنة الصادرة تحتاج الإنترنت.

### حل المشكلات
- **المنفذ 3000 مشغول**: أغلق التطبيق الآخر الذي يستخدمه ثم شغّل
  `windows\start.bat` من جديد.
- **مضاد الفيروسات يبطئ التثبيت**: اسمح للمجلد — التطبيق خادم Node
  محلي ولا يشغّل أي كود خارجي على جهازك.
- **صفحة فارغة عند أول تشغيل**: الخادم يجمع الملفات في الدقيقة الأولى —
  حدّث الصفحة بعد نحو 60 ثانية.
